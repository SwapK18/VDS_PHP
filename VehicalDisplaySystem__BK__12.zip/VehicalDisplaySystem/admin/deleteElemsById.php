<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include ('includes/config.php');
error_reporting(0);

$input = json_decode(file_get_contents('php://input'));
$typez = $input->type;
$delId = $input->idz;

// Brand delete
if ($typez == 'subscriber') {
	$sql = "DELETE FROM tblsubscribers WHERE id = '" . $delId . "'";
}

if ($typez == 'Brand') {
    $sql = "DELETE FROM tblbrands WHERE id = '" . $delId . "'";
}

// vehical delete
if ($typez == 'Vehical') {$sql = "DELETE FROM tblvehicles WHERE id = '" . $delId . "'";}

$query = $dbh->prepare($sql);
$lastInsertId = $dbh->lastInsertId();

if ($query->execute())
{
    $output = json_encode(array(
        "message" => "Record deleted successfully",
        "status" => true
    ));
    http_response_code(200);
}
else
{
    $output = json_encode(array(
        "message" => "Record deletion failed",
        "status" => false
    ));
}
echo ($output);
?>