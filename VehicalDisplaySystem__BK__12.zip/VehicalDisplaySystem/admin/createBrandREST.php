<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include ('includes/config.php');
error_reporting(0);



$input = json_decode(file_get_contents('php://input'));
$brandz = $input->brnd;


    $sql="INSERT INTO tblbrands(BrandName, isChecked) VALUES('".$brandz."', 0)";
    $query = $dbh->prepare($sql);
    $lastInsertId = $dbh->lastInsertId();

if($query->execute())
{
    $output = json_encode(array(
        "message" => "Data Inserted",
        "status" => true,
        "lastInserID" => $lastInsertId
    ));
    http_response_code(200);    
}
else
{
    $output = json_encode(array(
        "message" => "Insertion failed",
        "status" => false,
        "lastInserID" => null
    ));
    http_response_code(401);
    
}
echo ($output);
?>