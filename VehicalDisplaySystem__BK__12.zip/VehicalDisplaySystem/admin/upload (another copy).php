<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, GET, POST");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

$images = array();

$folderPath = "uploads/";

$file_names = $_FILES["file"]["name"];

$countFiles = count($file_names);

for ($i = 0; $i < $countFiles; $i++)
{

    $file_name = $file_names[$i];
    $image_info = explode(".", $file_name);
    $image_type = end($image_info);
    $original_file_name = pathinfo($file_name, PATHINFO_FILENAME);
    $file_url = $original_file_name . "-" . date("YmdHis") . "." . $image_type;

    array_push($images, $file_url);
    move_uploaded_file($_FILES["file"]["tmp_name"][$i], $folderPath . $file_url);

}
    var_dump($images);
?>