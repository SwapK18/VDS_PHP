<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include ('includes/config.php');
error_reporting(0);

$input = json_decode(file_get_contents('php://input'));
$contQryAction = $input->action;
$contQryRecIdz = (int)$input->qryRecId;

if($contQryAction === 'read'){
    $status = 1;

    $sql = "UPDATE tblcontactusquery SET status=:stus WHERE id=:aeid";
    $query = $dbh->prepare($sql);
    $query -> bindParam(':stus',$status, PDO::PARAM_STR);
    $query-> bindParam(':aeid',$contQryRecIdz, PDO::PARAM_INT);

    if ($query->execute())
    {
        $output = json_encode(array(
            "message" => "Query marked as unread",
            "status" => true,
        ));
        http_response_code(200);
    }
    else
    {
        $output = json_encode(array(
            "message" => "Query unread marking failed",
            "status" => false,
        ));
        http_response_code(401);

    }

}

if($contQryAction === 'unread'){
    $status = 0;

    $sql = "UPDATE tblcontactusquery SET status=:stus WHERE id=:eid";
    $query = $dbh->prepare($sql);
    $query -> bindParam(':stus',$status, PDO::PARAM_STR);
    $query-> bindParam(':eid',$contQryRecIdz, PDO::PARAM_INT);

    if ($query->execute())
    {
        $output = json_encode(array(
            
            "message" => "Query successfully marked as read",
            "status" => true,
        ));
        http_response_code(200);
    }
    else
    {
        $output = json_encode(array(
            "message" => "Query read marking failed",
            "status" => false,
        ));
        http_response_code(401);
    }
}

echo $output;
?>
