<?php
require_once ("./includes/config.php");

// header("Access-Control-Allow-Origin: *");
// header("Content-Type: application/json; charset=UTF-8");
// header("Access-Control-Allow-Methods: PUT,GET,POST");
// header("Access-Control-Max-Age: 3600");
// header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
// error_reporting(1);

 header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Methods: PUT, GET, POST");
    header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

$folderPath = "uploads/";

echo("swapnil kadu");
exit();


$file_nameOnesOne = $_FILES["imageOne"]["name"][0];
$file_nameOnesTwo = $_FILES["imageTwo"]["name"][0];
$vehicleTitle = $_REQUEST['vTitle'];


    $file_nameOne = $file_nameOnesOne;
    $image_infoOne = explode(".", $file_nameOne);
    $image_typeOne = end($image_infoOne);
    $original_file_nameOne = pathinfo($file_nameOne, PAT HINFO_FILENAME);
    $file_urlOne = $original_file_nameOne . "-" . date("YmdHis") . "." . $image_typeOne;
    move_uploaded_file($_FILES["imageOne"]["tmp_name"][0], $folderPath . $file_urlOne);


$output = "";
$sql = "INSERT INTO tblvehicles(VehiclesTitle, Vimage1) VALUES('".$vehicleTitle."','".$file_urlOne."')";

?>