<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET,POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include ('includes/config.php');
error_reporting(1);

$input = json_decode(file_get_contents('php://input'));
$pageId = $input->pageId;

if ($pageId != null)
{
    $query = "SELECT * FROM tblpages WHERE id='" . $pageId . "' ";

}
else if ($pageId == null)
{
    $query = "SELECT * FROM tblpages WHERE 1 ";
}

$allPages = array();
$statement = $dbh->prepare($query);
$statement->execute();
$total_row = $statement->rowCount();
$output = '';

if ($total_row > 0)
{
    while ($row = $statement->fetch(PDO::FETCH_ASSOC))
    {

        $allPages[] = ($row);

    }
    // http_response_code(200);
    $output = json_encode(array(
        "message" => "Pages found.",
        "status" => true,
        "data" => $allPages
    ));
    // $output = json_encode($allCars);
    
}
else
{
    $output = json_encode(array(
        "message" => "No pages found",
        "status" => false
    ));
}
echo ($output);
?>
