<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET,POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include ('includes/config.php');
error_reporting(1);

$query = "SELECT * FROM tblsubscribers WHERE 1 ";

$allSubscribers = array();
$statement = $dbh->prepare($query);
$statement->execute();
$total_row = $statement->rowCount();
$output = '';

if ($total_row > 0)
{
    while ($row = $statement->fetch(PDO::FETCH_ASSOC))
    {

        $allSubscribers = $row;

    }
    http_response_code(200);
    $output = json_encode(array(
        "message" => "Subscribers found.",
        "status" => true,
        "data" => [$allSubscribers]
    ));
    // $output = json_encode($allCars);
    
}
else
{
    $output = json_encode(array(
        "message" => "No Subscribers found",
        "status" => false
    ));
}
echo ($output);
?>
